### Todo App with Typescript and Redux

1. Download and extract file

2. In the root file run:
> `npm start`

Enjoy! 

: D
